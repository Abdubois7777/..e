import { useState } from "react";
import "./App.css";

function App() {
  const [darkMode, setDarkMode] = useState(true);

  const toggleMode = () => {
    setDarkMode(!darkMode);
  };

  return (
    <div className={darkMode ? "app dark" : "app light"}>
      <h1>{darkMode ? "DARKMODE" : "LIGHTMODE"}</h1>

      <div className="toggle" onClick={toggleMode}>
        <span className="text">{darkMode ? "ON" : "OFF"}</span>
        <div className={`circle ${darkMode ? "circle-dark" : "circle-light"}`} />
      </div>
    </div>
  





  );
}

export default App;


